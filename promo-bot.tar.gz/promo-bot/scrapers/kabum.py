"""Kabum: API pública pra listar + __NEXT_DATA__ da página pro preço REAL."""
import requests
from bs4 import BeautifulSoup
import urllib.parse
import json
import time

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
}

API_URL = "https://servicespub.prod.api.aws.grupokabum.com.br/catalog/v2/products"


def _preco_real_pagina(url_produto: str) -> dict:
    """Pega preços REAIS da página via __NEXT_DATA__ (a API pode ter preços desatualizados)."""
    try:
        r = requests.get(url_produto, headers=HEADERS, timeout=10)
        if r.status_code != 200:
            return None
        soup = BeautifulSoup(r.text, "html.parser")
        nd = soup.select_one("script#__NEXT_DATA__")
        if not nd or not nd.string:
            return None
        data = json.loads(nd.string)
        product = data.get("props", {}).get("pageProps", {}).get("product", {})
        if not product:
            return None
        prices = product.get("prices", {})
        pix = float(prices.get("priceWithDiscount") or product.get("price", 0))
        normal = float(prices.get("price") or 0)
        antigo = float(prices.get("oldPrice") or 0)
        return {
            "pix": pix,
            "normal": normal,
            "antigo": antigo,
            "desconto_pct": prices.get("discountPercentage", 0),
        }
    except Exception:
        return None


def buscar(termo: str, limite: int = 10) -> list:
    termo_enc = urllib.parse.quote(termo)
    url = f"{API_URL}?query={termo_enc}&page_number=1&page_size={limite}&facet_filters=&sort=most_searched"
    try:
        r = requests.get(url, headers=HEADERS, timeout=15)
        if r.status_code != 200:
            return []
        data = r.json()
        resultados = []

        for item in data.get("data", [])[:limite]:
            attrs = item.get("attributes", {})
            titulo = attrs.get("title") or attrs.get("description", "")
            if not titulo or not attrs.get("available", True):
                continue

            prod_id = item.get("id", "")
            slug = attrs.get("product_link") or titulo.lower().replace(" ", "-")[:80]
            url_prod = f"https://www.kabum.com.br/produto/{prod_id}/{slug}"

            # Imagem
            imagem = None
            photos = attrs.get("photos")
            if isinstance(photos, dict):
                for size in ["m", "g", "p"]:
                    urls = photos.get(size, [])
                    if urls and isinstance(urls, list):
                        imagem = urls[0]
                        break

            # PREÇO REAL da página
            info = _preco_real_pagina(url_prod)
            if info and info.get("pix") and info["pix"] > 0:
                preco_pix = info["pix"]
                preco_normal = info.get("normal", 0)
                preco_antigo = info.get("antigo", 0)

                preco_anterior = None
                if preco_antigo > preco_pix:
                    preco_anterior = preco_antigo
                elif preco_normal > preco_pix:
                    preco_anterior = preco_normal

                parcela = ""
                if preco_normal and preco_normal > preco_pix:
                    parcela = f"10x de R$ {preco_normal / 10:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
            else:
                preco_pix = float(attrs.get("price_with_discount") or attrs.get("price", 0))
                if preco_pix <= 0:
                    continue
                preco_anterior = None
                parcela = attrs.get("max_installment", "")

            resultados.append({
                "titulo": titulo,
                "url": url_prod,
                "preco": preco_pix,
                "preco_anterior": preco_anterior,
                "parcela": parcela,
                "imagem": imagem,
                "loja": "Kabum",
            })
            time.sleep(0.3)

        return resultados
    except Exception as e:
        print(f"[Kabum] erro '{termo}': {e}")
        return []
