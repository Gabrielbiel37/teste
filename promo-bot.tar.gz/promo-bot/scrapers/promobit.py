"""Promobit: ofertas da homepage via __NEXT_DATA__ (SSR)."""
import requests
from bs4 import BeautifulSoup
import json
import time

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
}

_cache = {"data": None, "ts": 0}


def _todas_ofertas() -> list:
    """Pega todas as ofertas da homepage (cache 5min)."""
    now = time.time()
    if _cache["data"] and (now - _cache["ts"]) < 300:
        return _cache["data"]

    try:
        r = requests.get("https://www.promobit.com.br/", headers=HEADERS, timeout=15)
        if r.status_code != 200:
            return []
        soup = BeautifulSoup(r.text, "html.parser")
        nd = soup.select_one("script#__NEXT_DATA__")
        if not nd or not nd.string:
            return []
        data = json.loads(nd.string)
        props = data.get("props", {}).get("pageProps", {})

        offers = []
        server = props.get("serverOffers", {})
        if isinstance(server, dict):
            offers = server.get("offers", [])
        featured = props.get("serverFeaturedOffers", [])
        if isinstance(featured, list):
            offers = offers + featured

        resultados = []
        for o in offers:
            if not isinstance(o, dict):
                continue
            titulo = o.get("offerTitle", "")
            preco = o.get("offerPrice", 0)
            if not titulo or not preco or float(preco) <= 0:
                continue
            slug = o.get("offerSlug", "")
            if not slug:
                continue
            preco_old = o.get("offerOldPrice", 0)
            preco_old = float(preco_old) if preco_old and float(preco_old) > float(preco) else None
            store = o.get("storeName", "Promobit")
            resultados.append({
                "titulo": titulo,
                "url": f"https://www.promobit.com.br/oferta/{slug}",
                "preco": float(preco),
                "preco_anterior": preco_old,
                "parcela": "",
                "imagem": o.get("offerPhoto"),
                "loja": f"Promobit ({store})",
                "_lower": titulo.lower(),
            })

        _cache["data"] = resultados
        _cache["ts"] = now
        return resultados
    except Exception as e:
        print(f"[Promobit] erro: {e}")
        return []


def buscar(termo: str, limite: int = 10) -> list:
    todas = _todas_ofertas()
    termos = [t for t in termo.lower().split() if len(t) > 2]
    resultados = []
    for o in todas:
        if any(t in o["_lower"] for t in termos):
            resultados.append({k: v for k, v in o.items() if k != "_lower"})
            if len(resultados) >= limite:
                break
    return resultados
