"""Notícias via RSS: Adrenaline, Tecmundo, IGN Brasil, Canaltech, The Enemy."""
import feedparser
import re
from config import FEEDS_NOTICIAS


def _limpar(txt: str) -> str:
    return re.sub(r"<[^>]+>", "", txt).strip()


def buscar_noticias(max_por_fonte: int = 3) -> list:
    noticias = []
    for fonte, url in FEEDS_NOTICIAS:
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:max_por_fonte]:
                titulo = _limpar(entry.get("title", ""))
                link = entry.get("link", "")
                resumo = _limpar(entry.get("summary", "") or entry.get("description", ""))
                if not titulo or not link:
                    continue
                noticias.append({
                    "titulo": titulo,
                    "resumo": resumo[:500],
                    "url": link,
                    "fonte": fonte,
                })
        except Exception as e:
            print(f"[RSS] erro {fonte}: {e}")
    return noticias
