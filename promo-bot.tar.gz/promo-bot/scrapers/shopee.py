"""Shopee: usa API de Afiliados oficial. Sem credenciais = retorna vazio."""
import os
import time
import hmac
import hashlib
import requests


def _tem_credenciais() -> bool:
    return bool(os.getenv("SHOPEE_PARTNER_ID") and os.getenv("SHOPEE_PARTNER_KEY"))


def buscar(termo: str, limite: int = 10) -> list:
    """Sem credenciais de afiliado, retorna lista vazia."""
    if not _tem_credenciais():
        return []

    partner_id = int(os.getenv("SHOPEE_PARTNER_ID", "0"))
    partner_key = os.getenv("SHOPEE_PARTNER_KEY", "")

    path = "/api/v1/product/search"
    t = int(time.time())
    base = f"{partner_id}{path}{t}"
    sign = hmac.new(partner_key.encode(), base.encode(), hashlib.sha256).hexdigest()

    try:
        r = requests.get(
            f"https://affiliate.shopee.com.br{path}",
            params={
                "partner_id": partner_id, "keyword": termo,
                "limit": limite, "sort_type": 2, "sign": sign, "timestamp": t,
            },
            timeout=15,
        )
        if r.status_code != 200:
            return []

        data = r.json()
        items = data.get("data", {}).get("product_list", [])
        resultados = []
        for item in items[:limite]:
            preco = item.get("price", 0)
            if preco > 100000:
                preco = preco / 100000
            titulo = item.get("product_name", "")
            url_prod = item.get("product_link", "")
            if not titulo or not preco:
                continue
            resultados.append({
                "titulo": titulo,
                "url": url_prod,
                "preco": float(preco),
                "preco_anterior": None,
                "parcela": "",
                "imagem": item.get("image_url"),
                "loja": "Shopee",
            })
        return resultados
    except Exception as e:
        print(f"[Shopee] erro: {e}")
        return []
