"""AliExpress: scraping HTML com cookies BR. Detecta moeda automaticamente."""
import requests
from bs4 import BeautifulSoup
import urllib.parse
import re

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
}
COOKIES = {"x-hng": "lang=pt-BR&currency=BRL", "intl_locale": "pt_BR"}
USD_BRL = 5.60


def _parse_preco_com_moeda(txt: str):
    """
    Extrai preço e detecta se está em BRL.
    Retorna: (valor, eh_brl)
    """
    if not txt:
        return None, False
    
    txt = txt.strip()
    
    # Detecta se está em reais
    eh_brl = 'R$' in txt or 'BRL' in txt.upper()
    
    # Remove símbolos
    txt = re.sub(r"[US$R\s]", "", txt)
    
    # Formata número
    if "," in txt and "." in txt:
        txt = txt.replace(".", "").replace(",", ".")
    elif "," in txt:
        txt = txt.replace(",", ".")
    
    try:
        valor = float(txt)
        return valor, eh_brl
    except ValueError:
        return None, False


def buscar(termo: str, limite: int = 10) -> list:
    termo_enc = urllib.parse.quote(termo)
    url = f"https://www.aliexpress.com/w/wholesale-{termo_enc}.html"
    try:
        r = requests.get(url, headers=HEADERS, cookies=COOKIES, timeout=15)
        if r.status_code != 200:
            return []

        soup = BeautifulSoup(r.text, "html.parser")
        produtos = soup.select('[class*="search-item-card-wrapper-gallery"]')
        resultados = []

        for prod in produtos[:limite]:
            try:
                title_el = prod.select_one('[class*="title"]')
                titulo = title_el.get_text(strip=True) if title_el else ""
                if not titulo or len(titulo) < 10:
                    continue

                price_el = prod.select_one('[class*="price-sale"]') or prod.select_one('[class*="price"]')
                if not price_el:
                    continue
                
                preco_bruto, eh_brl = _parse_preco_com_moeda(price_el.get_text())
                if not preco_bruto:
                    continue
                
                # Converte só se estiver em dólar
                preco_final = preco_bruto if eh_brl else round(preco_bruto * USD_BRL, 2)

                link_el = prod.select_one('a')
                href = link_el.get('href', '') if link_el else ""
                if href.startswith('//'):
                    href = 'https:' + href
                if not href:
                    continue

                img_el = prod.select_one('img')
                imagem = None
                if img_el:
                    imagem = img_el.get('src') or img_el.get('data-src')
                    if imagem and imagem.startswith('//'):
                        imagem = 'https:' + imagem

                sold_el = prod.select_one('[class*="sold"]')
                vendidos = sold_el.get_text(strip=True) if sold_el else ""
                if vendidos:
                    titulo = f"{titulo} ({vendidos})"

                resultados.append({
                    "titulo": titulo,
                    "url": href,
                    "preco": preco_final,
                    "preco_anterior": None,
                    "parcela": "",
                    "imagem": imagem,
                    "loja": "AliExpress",
                })
            except Exception:
                continue

        return resultados
    except Exception as e:
        print(f"[AliExpress] erro '{termo}': {e}")
        return []
