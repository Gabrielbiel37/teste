"""
🤖 Promo Bot Gamer - Bot de promoções de hardware e notícias para Telegram
Otimizado para rodar em dispositivos leves (Galaxy J2 Prime / Termux / servidores)
Fontes: Kabum (API+HTML), AliExpress (HTML com detecção de moeda), Promobit (Next.js), RSS, Shopee (afiliado)
IA: Groq (API HTTP direta - qwen3.8-27b)
"""
import os
import sys
import time
import schedule
from datetime import datetime
from dotenv import load_dotenv

# Carrega .env do mesmo diretório do script de forma confiável
ENV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
load_dotenv(dotenv_path=ENV_PATH)

from config import (
    INTERVALO_MINUTOS, DESCONTO_MINIMO, CATEGORIAS, LOJAS_ATIVAS,
    POSTAR_NOTICIAS, INTERVALO_NOTICIAS_HORAS, ENVIAR_FOTO,
    PALAVRAS_PROIBIDAS, MODELO_IA
)
from utils.database import (
    init_db, ja_postado, salvar_promo, salvar_historico,
    menor_preco_historico, noticia_postada, salvar_noticia
)
from utils.telegram_bot import enviar_texto, enviar_foto
from utils.ia import avaliar_promo, gerar_post_promo, resumir_noticia

# Scrapers que funcionam
from scrapers import kabum, aliexpress, promobit, shopee, noticias_rss

SCRAPERS = {
    "kabum": kabum,
    "aliexpress": aliexpress,
    "promobit": promobit,
    "shopee": shopee,
}


def checar_promos():
    """Busca promoções em todas as lojas ativas e posta no Telegram."""
    print(f"\n[{datetime.now():%H:%M:%S}] 🔍 Checando promos...")
    total_postadas = 0
    total_filtradas = 0

    for categoria, termos in CATEGORIAS.items():
        for termo in termos:
            for loja_nome, ativo in LOJAS_ATIVAS.items():
                if not ativo:
                    continue
                scraper = SCRAPERS.get(loja_nome)
                if not scraper:
                    continue

                try:
                    produtos = scraper.buscar(termo, limite=5)
                except Exception as e:
                    print(f"  ❌ {loja_nome} '{termo}': {e}")
                    continue

                for p in produtos:
                    try:
                        # URL válida
                        url = p.get("url", "")
                        if not url or len(url) < 10:
                            continue

                        # Já postado
                        if ja_postado(url):
                            salvar_historico(url, p["preco"])
                            continue

                        # Palavras proibidas
                        titulo_lower = (p.get("titulo") or "").lower()
                        if any(pal in titulo_lower for pal in PALAVRAS_PROIBIDAS):
                            total_filtradas += 1
                            continue

                        # Desconto mínimo
                        if p.get("preco_anterior"):
                            desc = ((p["preco_anterior"] - p["preco"]) / p["preco_anterior"]) * 100
                            if desc < DESCONTO_MINIMO:
                                salvar_historico(url, p["preco"])
                                continue

                        # IA avalia
                        menor = menor_preco_historico(url)
                        avaliacao = avaliar_promo(p["titulo"], p["preco"], menor)
                        if not avaliacao.get("vale"):
                            salvar_historico(url, p["preco"])
                            continue

                        # Gera post
                        texto = gerar_post_promo(
                            p["titulo"], p["preco"], p.get("preco_anterior"),
                            p["loja"], url, p.get("parcela", "")
                        )
                        texto = f"🏷️ _{categoria}_\n\n{texto}"

                        # Envia pro Telegram
                        if ENVIAR_FOTO and p.get("imagem"):
                            ok = enviar_foto(p["imagem"], texto)
                        else:
                            ok = enviar_texto(texto)

                        if ok:
                            salvar_promo(url, p["titulo"], p["loja"],
                                         p["preco"], p.get("preco_anterior"))
                            salvar_historico(url, p["preco"])
                            total_postadas += 1
                            print(f"  ✅ [{p['loja']}] {p['titulo'][:50]}")
                            time.sleep(3)
                    except Exception as err_item:
                        print(f"  ⚠️ Erro ao processar item {p.get('titulo', '')[:30]}: {err_item}")
                        continue

    print(f"[{datetime.now():%H:%M:%S}] ✔ {total_postadas} postada(s) | 🚫 {total_filtradas} filtrada(s)")


def checar_noticias():
    """Busca notícias via RSS e posta no Telegram."""
    if not POSTAR_NOTICIAS:
        return
    print(f"\n[{datetime.now():%H:%M:%S}] 📰 Checando notícias...")
    try:
        noticias = noticias_rss.buscar_noticias(max_por_fonte=2)
        postadas = 0
        for n in noticias:
            if not n["url"] or noticia_postada(n["url"]):
                continue
            texto = resumir_noticia(n["titulo"], n["resumo"], n["url"], n["fonte"])
            if enviar_texto(texto):
                salvar_noticia(n["url"])
                postadas += 1
                time.sleep(3)
        print(f"[{datetime.now():%H:%M:%S}] ✔ {postadas} notícia(s)")
    except Exception as e:
        print(f"❌ Erro ao checar notícias: {e}")


def main():
    faltando = [k for k in ("TELEGRAM_TOKEN", "TELEGRAM_CHAT_ID", "GROQ_API_KEY")
                if not os.getenv(k)]
    if faltando:
        print(f"❌ Variáveis faltando no .env: {faltando}")
        print("Edite o arquivo .env com suas chaves.")
        return

    init_db()
    print("=" * 50)
    print("🤖 PROMO BOT GAMER - Online no J2 Prime!")
    print("=" * 50)
    print(f"  Promos: a cada {INTERVALO_MINUTOS} min")
    print(f"  Notícias: a cada {INTERVALO_NOTICIAS_HORAS} h")
    ativas = [k for k, v in LOJAS_ATIVAS.items() if v]
    print(f"  Lojas: {', '.join(ativas)}")
    if "shopee" in ativas and not os.getenv("SHOPEE_PARTNER_ID"):
        print(f"  ⚠ Shopee sem credenciais (vazio)")
    print(f"  IA: {MODELO_IA} (Groq HTTP)")
    print(f"  Filtros: {len(PALAVRAS_PROIBIDAS)} palavras proibidas")
    print("=" * 50)

    try:
        enviar_texto("🤖 *Promo Bot online!* Caçando as melhores promos 🔥")
    except Exception as e:
        print(f"Aviso ao enviar mensagem de início: {e}")

    try:
        checar_promos()
        if POSTAR_NOTICIAS:
            checar_noticias()
    except Exception as e:
        print(f"Aviso na primeira rodada: {e}")

    schedule.every(INTERVALO_MINUTOS).minutes.do(checar_promos)
    schedule.every(INTERVALO_NOTICIAS_HORAS).hours.do(checar_noticias)

    print(f"[{datetime.now():%H:%M:%S}] ⏳ Aguardando próximos ciclos... (Ctrl+C para parar)")
    while True:
        try:
            schedule.run_pending()
            time.sleep(30)
        except KeyboardInterrupt:
            print("\nEncerrando bot...")
            break
        except Exception as e:
            print(f"Erro no loop principal: {e}")
            time.sleep(30)


if __name__ == "__main__":
    main()
