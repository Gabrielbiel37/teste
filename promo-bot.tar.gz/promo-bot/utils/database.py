"""SQLite: histórico de preços e controle de duplicatas."""
import os
import sqlite3
from typing import Optional

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "promos.db")


def _conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return sqlite3.connect(DB_PATH)


def init_db():
    with _conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS promos (
            url TEXT PRIMARY KEY, titulo TEXT, loja TEXT,
            preco REAL, preco_anterior REAL, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS historico_precos (
            url TEXT, preco REAL, data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS noticias (
            url TEXT PRIMARY KEY, data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")


def ja_postado(url: str) -> bool:
    with _conn() as c:
        return c.execute("SELECT 1 FROM promos WHERE url=?", (url,)).fetchone() is not None


def salvar_promo(url, titulo, loja, preco, preco_anterior):
    with _conn() as c:
        c.execute("INSERT OR REPLACE INTO promos VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)",
                  (url, titulo, loja, preco, preco_anterior))


def salvar_historico(url, preco):
    with _conn() as c:
        c.execute("INSERT INTO historico_precos (url, preco) VALUES (?,?)", (url, preco))


def menor_preco_historico(url: str) -> Optional[float]:
    with _conn() as c:
        row = c.execute("SELECT MIN(preco) FROM historico_precos WHERE url=?", (url,)).fetchone()
        return row[0] if row and row[0] else None


def noticia_postada(url: str) -> bool:
    with _conn() as c:
        return c.execute("SELECT 1 FROM noticias WHERE url=?", (url,)).fetchone() is not None


def salvar_noticia(url: str):
    with _conn() as c:
        c.execute("INSERT OR IGNORE INTO noticias (url) VALUES (?)", (url,))
