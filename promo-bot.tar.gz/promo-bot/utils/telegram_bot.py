"""Telegram: envio de mensagens via API HTTP."""
import os
import time
import requests


def _token():
    return os.getenv("TELEGRAM_TOKEN", "")

def _chat_id():
    return os.getenv("TELEGRAM_CHAT_ID", "")

def _api(method):
    return f"https://api.telegram.org/bot{_token()}/{method}"


def enviar_texto(texto: str) -> bool:
    try:
        r = requests.post(_api("sendMessage"), json={
            "chat_id": _chat_id(),
            "text": texto,
            "parse_mode": "Markdown",
            "disable_web_page_preview": False,
        }, timeout=15)
        if r.status_code == 200:
            return True
        # Se falhou por causa do parse_mode Markdown, tenta sem formatação
        r_plain = requests.post(_api("sendMessage"), json={
            "chat_id": _chat_id(),
            "text": texto,
            "disable_web_page_preview": False,
        }, timeout=15)
        if r_plain.status_code == 200:
            return True
        print(f"[Telegram] erro: {r.status_code} {r.text[:100]}")
        return False
    except Exception as e:
        print(f"[Telegram] {e}")
        return False
    finally:
        time.sleep(1)


def enviar_foto(foto_url: str, legenda: str) -> bool:
    try:
        r = requests.post(_api("sendPhoto"), json={
            "chat_id": _chat_id(),
            "photo": foto_url,
            "caption": legenda,
            "parse_mode": "Markdown",
        }, timeout=15)
        if r.status_code == 200:
            return True
        # Fallback: envia só texto
        return enviar_texto(legenda)
    except Exception as e:
        print(f"[Telegram foto] {e}")
        return enviar_texto(legenda)
    finally:
        time.sleep(1)
