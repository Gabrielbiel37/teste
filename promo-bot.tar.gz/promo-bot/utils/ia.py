"""IA via Groq (chamada direta via requests - 100% compatível com Python 3.8 e Termux 32-bit)."""
import os
import json
import requests
from config import USAR_IA, MODELO_IA


def _chamar_groq(messages: list, json_mode: bool = False, temperature: float = 0.5, max_tokens: int = 300) -> str:
    """Faz a requisição HTTP direta para a API da Groq sem precisar do pacote openai."""
    api_key = os.getenv("GROQ_API_KEY", "")
    if not api_key:
        raise ValueError("GROQ_API_KEY não configurada no .env")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": MODELO_IA,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}

    r = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers=headers,
        json=payload,
        timeout=20,
    )
    if r.status_code != 200:
        raise RuntimeError(f"Erro Groq {r.status_code}: {r.text[:200]}")

    data = r.json()
    return data["choices"][0]["message"]["content"].strip()


def avaliar_promo(titulo: str, preco: float, menor_hist: float = None) -> dict:
    """Retorna {"vale": bool, "motivo": str, "nota": int}"""
    if not USAR_IA:
        return {"vale": True, "motivo": "IA off", "nota": 7}

    hist = ""
    if menor_hist:
        diff = ((preco - menor_hist) / menor_hist) * 100
        hist = f"Menor histórico: R$ {menor_hist:.2f} (atual {diff:+.1f}%)."

    prompt = f"""Você é curador de promos de hardware gamer no Brasil.
Produto: {titulo}
Preço: R$ {preco:.2f}
{hist}
Responda SÓ JSON: {{"vale": true, "motivo": "frase curta", "nota": 7}}
Se não souber o preço justo, vale=true nota=6."""

    try:
        conteudo = _chamar_groq([{"role": "user", "content": prompt}], json_mode=True, temperature=0.3, max_tokens=200)
        return json.loads(conteudo)
    except Exception as e:
        print(f"[IA avaliar] {e}")
        return {"vale": True, "motivo": "fallback", "nota": 7}


def gerar_post_promo(titulo: str, preco: float, preco_ant: float, loja: str, url: str, parcela: str = "") -> str:
    """Gera post formatado pro Telegram."""
    if not USAR_IA:
        return _fallback(titulo, preco, preco_ant, loja, url, parcela)

    parc = f"\nParcelado: {parcela}" if parcela else ""
    prompt = f"""Post curto e chamativo pra Telegram (markdown). 2-3 emojis. NÃO invente specs.
Produto: {titulo}
Loja: {loja}
PIX: R$ {preco:.2f}
Anterior: {f"R$ {preco_ant:.2f}" if preco_ant else "?"}{parc}
Link: {url}

Formato:
🔥 *Produto*
💸 De Rxx por *Ryy* (Z% OFF) no PIX
💳 parcela
🏪 Loja
🛒 [Comprar](link)

SÓ o post, sem explicação."""

    try:
        return _chamar_groq([{"role": "user", "content": prompt}], temperature=0.7, max_tokens=300)
    except Exception as e:
        print(f"[IA post] {e}")
        return _fallback(titulo, preco, preco_ant, loja, url, parcela)


def resumir_noticia(titulo: str, resumo: str, link: str, fonte: str) -> str:
    """Resume notícia pro Telegram."""
    if not USAR_IA:
        return f"📰 *{titulo}*\n{resumo[:200]}...\n🔗 [Leia em {fonte}]({link})"

    prompt = f"""Resuma em 2 frases curtas pra Telegram. 1 emoji.
Título: {titulo}
Conteúdo: {resumo[:500]}

Formato:
📰 *Título chamativo*
Resumo 2 frases.
🔗 [Leia em {fonte}]({link})"""

    try:
        return _chamar_groq([{"role": "user", "content": prompt}], temperature=0.6, max_tokens=300)
    except Exception as e:
        print(f"[IA noticia] {e}")
        return f"📰 *{titulo}*\n{resumo[:200]}...\n🔗 [Leia em {fonte}]({link})"


def _fallback(titulo, preco, preco_ant, loja, url, parcela):
    if preco_ant and preco_ant > preco:
        d = ((preco_ant - preco) / preco_ant) * 100
        linha = f"\n💸 De R$ {preco_ant:.2f} por *R$ {preco:.2f}* ({d:.0f}% OFF) no PIX"
    else:
        linha = f"\n💰 *R$ {preco:.2f}* no PIX"
    parc = f"\n💳 {parcela}" if parcela else ""
    return f"🔥 *{titulo}*{linha}{parc}\n🏪 {loja}\n🛒 [Comprar]({url})"
