"""
Configurações do bot. Edite aqui pra personalizar.
"""

# ===== INTERVALOS =====
INTERVALO_MINUTOS = 30          # checar promos a cada X min
INTERVALO_NOTICIAS_HORAS = 3    # checar notícias a cada X h

# ===== DESCONTO =====
DESCONTO_MINIMO = 10  # só posta se desconto >= X% (0 = posta tudo)

# ===== CATEGORIAS (palavras-chave de busca) =====
CATEGORIAS = {
    "GPU / Placa de Vídeo": ["rtx 4060", "rtx 4070", "rtx 4080", "rx 7600", "rx 7700", "rx 7800"],
    "Processador": ["ryzen 5 7600", "ryzen 7 7700", "ryzen 5 5600", "core i5 14400", "core i7 14700", "ryzen 7 5700X"],
    "Memória RAM": ["memoria ddr5 16gb", "memoria ddr5 32gb", "memoria ddr4 16gb", "memoria ddr4 8gb"],
    "SSD / NVMe": ["ssd nvme 1tb", "ssd nvme 2tb", "ssd 500gb"],
    "Placa-mãe": ["placa mae b650", "placa mae b550", "placa mae b760"],
    "Mouse Gamer": ["mouse gamer", "mouse logitech g", "mouse razer"],
    "Teclado Gamer": ["teclado mecanico", "teclado gamer"],
    "Gabinete": ["gabinete gamer", "gabinete atx"],
    "Controle": ["controle xbox", "controle playstation", "controle dualsense"],
    "Jogos": ["steam jogo", "jogos pc"],
}

# ===== LOJAS =====
# True = ativo, False = desativado
LOJAS_ATIVAS = {
    "kabum": True,        # ✅ API + HTML (preço real)
    "aliexpress": True,   # ✅ HTML scraping (USD→BRL com detecção de moeda)
    "promobit": True,     # ✅ Next.js homepage
    "shopee": True,       # ⚠ Precisa API afiliado (vazio sem credenciais)
}

# ===== NOTÍCIAS =====
POSTAR_NOTICIAS = True
FEEDS_NOTICIAS = [
    ("Adrenaline", "https://www.adrenaline.com.br/feed/"),
    ("Tecmundo", "https://rss.tecmundo.com.br/feed"),
    ("The Enemy", "https://www.theenemy.com.br/rss"),
    ("IGN Brasil", "https://br.ign.com/feed.xml"),
    ("Canaltech", "https://canaltech.com.br/rss/"),
]

# ===== IA (Groq - grátis) =====
USAR_IA = True
MODELO_IA = "qwen/qwen3.8-27b"

# ===== TELEGRAM =====
ENVIAR_FOTO = True  # envia imagem do produto junto

# ===== FILTRO DE PRODUTOS =====
PALAVRAS_PROIBIDAS = [
    # PCs montados e kits
    "pc gamer", "pc completo", "computador", "desktop", "all in one", "notebook",
    "kit upgrade", "kit gamer", "kit gaming", "combo gamer", "setup gamer",
    # Hardware fraco
    "gt 710", "gt 730", "gt 1030", "celeron", "pentium", "athlon", "ddr3",
    # Estado do produto
    "usado", "recondicionado", "open box", "vitrine", "seminovo",
]
